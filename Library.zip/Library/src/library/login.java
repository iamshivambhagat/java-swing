package library;

import javax.swing.JOptionPane;

/**
 *
 * @author Shivam-Bhagat
 */
public class login extends javax.swing.JFrame {

  
    public login() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtuname = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        txtpass = new javax.swing.JPasswordField();
        btnreset = new javax.swing.JButton();
        btnsignup = new javax.swing.JButton();
        btnlogin = new javax.swing.JButton();
        lblforgotuser = new javax.swing.JLabel();
        lblpass = new javax.swing.JLabel();
        lbluname = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lblforgotpassword = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Login Form");
        setLocation(new java.awt.Point(0, 0));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/library/CIMAGE-Logo.jpg"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 530, 460));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 530, 460));

        jPanel2.setBackground(new java.awt.Color(0, 51, 102));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Password :");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, -1, -1));

        jLabel4.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("User Name :");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, -1, -1));

        txtuname.setBackground(new java.awt.Color(0, 51, 102));
        txtuname.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        txtuname.setForeground(new java.awt.Color(255, 255, 255));
        txtuname.setBorder(null);
        txtuname.setCaretColor(new java.awt.Color(255, 255, 255));
        txtuname.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        txtuname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtunameFocusGained(evt);
            }
        });
        jPanel2.add(txtuname, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 140, 210, 30));
        jPanel2.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, 220, 10));

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("X");
        jLabel5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 0, 50, 50));
        jPanel2.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 250, 220, 10));

        txtpass.setBackground(new java.awt.Color(0, 51, 102));
        txtpass.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        txtpass.setForeground(new java.awt.Color(255, 255, 255));
        txtpass.setBorder(null);
        txtpass.setCaretColor(new java.awt.Color(255, 255, 255));
        txtpass.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtpassFocusGained(evt);
            }
        });
        jPanel2.add(txtpass, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 220, 220, -1));

        btnreset.setBackground(new java.awt.Color(51, 38, 132));
        btnreset.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnreset.setForeground(new java.awt.Color(255, 255, 255));
        btnreset.setText("Reset");
        btnreset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresetActionPerformed(evt);
            }
        });
        jPanel2.add(btnreset, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 290, 90, -1));

        btnsignup.setBackground(new java.awt.Color(51, 38, 132));
        btnsignup.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnsignup.setForeground(new java.awt.Color(255, 255, 255));
        btnsignup.setText("Signup");
        btnsignup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsignupActionPerformed(evt);
            }
        });
        jPanel2.add(btnsignup, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 400, 120, 30));

        btnlogin.setBackground(new java.awt.Color(51, 38, 132));
        btnlogin.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        btnlogin.setForeground(new java.awt.Color(255, 255, 255));
        btnlogin.setText("Login");
        btnlogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnloginActionPerformed(evt);
            }
        });
        jPanel2.add(btnlogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 290, 90, -1));

        lblforgotuser.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblforgotuser.setForeground(new java.awt.Color(255, 255, 255));
        lblforgotuser.setText("Forget User");
        lblforgotuser.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblforgotuser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblforgotuserMouseClicked(evt);
            }
        });
        jPanel2.add(lblforgotuser, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 350, -1, 30));

        lblpass.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblpass.setForeground(new java.awt.Color(204, 0, 0));
        jPanel2.add(lblpass, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 260, 220, 20));

        lbluname.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lbluname.setForeground(new java.awt.Color(204, 0, 0));
        jPanel2.add(lbluname, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 180, 220, 20));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("New Register :-");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 400, -1, 30));

        lblforgotpassword.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblforgotpassword.setForeground(new java.awt.Color(255, 255, 255));
        lblforgotpassword.setText("Forget Password |");
        lblforgotpassword.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblforgotpassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblforgotpasswordMouseClicked(evt);
            }
        });
        jPanel2.add(lblforgotpassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 350, -1, 30));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Calibri", 1, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Login Form");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 0, 480, 460));

        setSize(new java.awt.Dimension(1026, 507));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnloginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnloginActionPerformed
        String unm,pass;
        unm=txtuname.getText();
        pass=txtpass.getText();
        String sql="select * from user_profile where user_name='"+unm+"' ";
        try {
            myconnection.rs=myconnection.stmt.executeQuery(sql);
            if(myconnection.rs.next())
            {
                if(myconnection.rs.getString(3).equals(pass))
                {
                    //JOptionPane.showMessageDialog(null,"Login Success ");
                    new home().setVisible(true);
                    this.dispose();
                    lblpass.setText("");
                }
                else
                {
                    lblpass.setText("Invalid Password");
                    txtpass.requestFocus();
                }

                lbluname.setText("");

            }
            else
            {
                lbluname.setText("Invalid User Name");
                txtuname.requestFocus();
            }

        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Login Failed"+e);
        }
    }//GEN-LAST:event_btnloginActionPerformed

    private void btnsignupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsignupActionPerformed
        new signup().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnsignupActionPerformed

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        this.dispose();
    }//GEN-LAST:event_jLabel5MouseClicked

    private void btnresetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresetActionPerformed
        txtuname.setText("");
        txtpass.setText("");
        lbluname.setText("");
        lblpass.setText("");
        txtuname.requestFocus();
    }//GEN-LAST:event_btnresetActionPerformed

    private void txtpassFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtpassFocusGained
        // txtpass.setText("");
    }//GEN-LAST:event_txtpassFocusGained

    private void txtunameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtunameFocusGained
        //txtuname.setText("");        // TODO add your handling code here:
    }//GEN-LAST:event_txtunameFocusGained

    private void lblforgotpasswordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblforgotpasswordMouseClicked
            new forget_password().setVisible(true);
            this.dispose();
    }//GEN-LAST:event_lblforgotpasswordMouseClicked

    private void lblforgotuserMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblforgotuserMouseClicked
            new forget_user().setVisible(true);
            this.dispose();
    }//GEN-LAST:event_lblforgotuserMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnlogin;
    private javax.swing.JButton btnreset;
    private javax.swing.JButton btnsignup;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lblforgotpassword;
    private javax.swing.JLabel lblforgotuser;
    private javax.swing.JLabel lblpass;
    private javax.swing.JLabel lbluname;
    private javax.swing.JPasswordField txtpass;
    private javax.swing.JTextField txtuname;
    // End of variables declaration//GEN-END:variables
}
