package library;
/**
 *
 * @author Shivam-Bhagat
 */
import java.sql.*;
import javax.swing.*;

public class myconnection {
    static Connection con;
    static Statement stmt;
    static ResultSet rs;
    static void connect()
    {
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","mu","cimage");
            stmt=con.createStatement();
            // JOptionPane.showMessageDialog(null,"Connection Successful");
        }
        catch(Exception e)
                {
                     JOptionPane.showMessageDialog(null,"Error During Connection"+e);
                }
    }
    
}
