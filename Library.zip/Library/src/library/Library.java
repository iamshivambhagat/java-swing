package library;

/**
 *
 * @author Shivam-Bhagat
 */
public class Library {
    public static void main(String[] args) {
        myconnection.connect();
        new login().setVisible(true);
        //new signup().setVisible(true);
    }
    
}
